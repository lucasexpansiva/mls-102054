var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupenterboolean/ml-toggle-switch-brutal.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// TOGGLE SWITCH — BRUTALISM (mls-102054) — Strategy D shell
// =============================================================================
// Skill Group: groupEnterBoolean
// Herda render() e toda a lógica de ToggleSwitchMolecule (mls-102040).
// Toda a aparência vive no .less escopado na tag -brutal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { ToggleSwitchMolecule } from '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch.js';
let ToggleSwitchBrutal = class ToggleSwitchBrutal extends ToggleSwitchMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupenterboolean--ml-toggle-switch-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-surface-dim: #e5e5e5;
  --ml-on-surface: #000000;
  --ml-error: #ef4444;
  --ml-shadow-1: 2px 2px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  display: block;
  font-family: var(--ml-font-family, monospace);
}
groupenterboolean--ml-toggle-switch-brutal .ml-label {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterboolean--ml-toggle-switch-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
}
groupenterboolean--ml-toggle-switch-brutal .ml-helper {
  color: #666;
  font-family: var(--ml-font-family, monospace);
}
groupenterboolean--ml-toggle-switch-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupenterboolean--ml-toggle-switch-brutal .ml-toggle-track {
  background: var(--ml-surface-dim, #e5e5e5);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: var(--ml-shadow-1, 2px 2px 0 #000000);
  transition: none;
}
groupenterboolean--ml-toggle-switch-brutal .ml-toggle-track:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupenterboolean--ml-toggle-switch-brutal .ml-toggle-track-on {
  background: var(--ml-primary, #3b82f6);
  border-color: var(--ml-outline-variant, #000000);
}
groupenterboolean--ml-toggle-switch-brutal .ml-toggle-track-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 2px 2px 0 #ef4444;
}
groupenterboolean--ml-toggle-switch-brutal .ml-toggle-thumb {
  background: #000000;
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: none;
  transform: translateX(0.25rem);
  transition: none;
}
groupenterboolean--ml-toggle-switch-brutal .ml-toggle-track-on .ml-toggle-thumb {
  background: #ffffff;
  transform: translateX(1.125rem);
}
groupenterboolean--ml-toggle-switch-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupenterboolean--ml-toggle-switch-brutal .ml-toggle-track.ml-disabled {
  border-color: #999;
  box-shadow: 2px 2px 0 #999;
}
`);
    }
};
ToggleSwitchBrutal = __decorate([
    customElement('groupenterboolean--ml-toggle-switch-brutal')
], ToggleSwitchBrutal);
export { ToggleSwitchBrutal };
