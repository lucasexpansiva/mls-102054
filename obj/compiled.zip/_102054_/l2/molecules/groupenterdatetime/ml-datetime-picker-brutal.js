var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupenterdatetime/ml-datetime-picker-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DATETIME PICKER — BRUTALISM (mls-102054)
// =============================================================================
// Skill Group: enter + datetime
// Casca (estratégia D): herda tudo de MlDatetimePickerMolecule (mls-102040),
// inclusive render() e getPortalTemplate() — o markup base emite classes ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag e sob o
// data-widget do portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlDatetimePickerMolecule } from '/_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker.js';
let DatetimePickerBrutal = class DatetimePickerBrutal extends MlDatetimePickerMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterdatetime--ml-datetime-picker-brutal,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] {
  display: block;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f0f0f0;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-radius-md: 0;
  --ml-radius-lg: 0;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-label,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-label {
  color: var(--ml-on-surface, #000000);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupenterdatetime--ml-datetime-picker-brutal .ml-error-text,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-error-text {
  color: var(--ml-error, #ef4444);
}
groupenterdatetime--ml-datetime-picker-brutal p.ml-error-text,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] p.ml-error-text {
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
}
groupenterdatetime--ml-datetime-picker-brutal .ml-helper,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-helper {
  color: #666666;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-text,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-text {
  color: var(--ml-on-surface, #000000);
}
groupenterdatetime--ml-datetime-picker-brutal .ml-text.font-medium,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-text.font-medium {
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
}
groupenterdatetime--ml-datetime-picker-brutal .ml-text-muted,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-text-muted {
  color: var(--ml-on-surface-muted, #999999);
}
groupenterdatetime--ml-datetime-picker-brutal svg.ml-text-muted,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] svg.ml-text-muted {
  color: var(--ml-on-surface, #000000);
}
groupenterdatetime--ml-datetime-picker-brutal .grid.ml-text-muted,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .grid.ml-text-muted {
  color: #666666;
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
}
groupenterdatetime--ml-datetime-picker-brutal .ml-disabled,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-spinner,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-spinner {
  border: 3px solid #cccccc;
  border-top-color: var(--ml-on-surface, #000000);
  border-radius: 0;
}
groupenterdatetime--ml-datetime-picker-brutal .animate-spin,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .animate-spin {
  animation-timing-function: steps(8);
}
groupenterdatetime--ml-datetime-picker-brutal .ml-input-container,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-md, 0);
  color: var(--ml-on-surface, #000000);
  cursor: pointer;
  box-shadow: 3px 3px 0 #000000;
  transition: none;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-input-container.ml-input-container-focused,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-input-container.ml-input-container-focused {
  outline: 3px solid #000000;
  outline-offset: 2px;
  box-shadow: 3px 3px 0 #000000;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-input-container.ml-input-container-error,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-input-container.ml-input-container-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 3px 3px 0 #ef4444;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-input-container.ml-disabled,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-input-container.ml-disabled {
  border-color: #999999;
  box-shadow: 3px 3px 0 #999999;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-container,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-lg, 0);
  box-shadow: 6px 6px 0 #000000;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-nav,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-nav {
  background: var(--ml-surface, #ffffff);
  border: 2px solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-md, 0);
  color: var(--ml-on-surface, #000000);
  cursor: pointer;
  font-weight: var(--ml-font-weight-medium, 700);
  box-shadow: 2px 2px 0 #000000;
  transition: none;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-nav:hover,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-nav:hover {
  background: #000000;
  color: #ffffff;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-nav:active,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-nav:active {
  box-shadow: none;
  transform: translate(2px, 2px);
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-nav.rounded-md,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-nav.rounded-md {
  text-transform: var(--ml-text-transform, uppercase);
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-day,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-day {
  border: 2px solid transparent;
  border-radius: var(--ml-radius-md, 0);
  color: var(--ml-on-surface, #000000);
  cursor: pointer;
  font-weight: var(--ml-font-weight-medium, 700);
  transition: none;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-day--hoverable:hover,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-day--hoverable:hover {
  background: var(--ml-surface-dim, #f0f0f0);
  border-color: var(--ml-outline-variant, #000000);
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-day-today,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-day-today {
  border-color: var(--ml-primary, #3b82f6);
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-day-selected,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-day-selected {
  background: #000000;
  border-color: #000000;
  color: #ffffff;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-day-disabled,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-day-disabled {
  opacity: 0.3;
  cursor: not-allowed;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-time-btn,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-time-btn {
  border: 2px solid transparent;
  border-radius: var(--ml-radius-md, 0);
  color: var(--ml-on-surface, #000000);
  cursor: pointer;
  font-weight: var(--ml-font-weight-medium, 700);
  transition: none;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-time-btn--hoverable:hover,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-time-btn--hoverable:hover {
  background: var(--ml-surface-dim, #f0f0f0);
  border-color: var(--ml-outline-variant, #000000);
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-time-btn-selected,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-time-btn-selected {
  background: #000000;
  border-color: #000000;
  color: #ffffff;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-time-btn.ml-disabled,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-time-btn.ml-disabled {
  opacity: 0.3;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-confirm,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-confirm {
  background: var(--ml-primary, #3b82f6);
  border: 2px solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-md, 0);
  color: var(--ml-on-primary, #ffffff);
  cursor: pointer;
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  box-shadow: 2px 2px 0 #000000;
  transition: none;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-confirm:hover,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-confirm:hover {
  background: #2563eb;
}
groupenterdatetime--ml-datetime-picker-brutal .ml-calendar-confirm:active,
div[data-widget="groupenterdatetime--ml-datetime-picker-brutal"] .ml-calendar-confirm:active {
  box-shadow: none;
  transform: translate(2px, 2px);
}
`);
        // O container do portal (document.body) recebe este data-widget — o .less do
        // tema escopa o painel por div[data-widget="...-brutal"].
        this.portalWidgetName = 'groupenterdatetime--ml-datetime-picker-brutal';
    }
};
DatetimePickerBrutal = __decorate([
    customElement('groupenterdatetime--ml-datetime-picker-brutal')
], DatetimePickerBrutal);
export { DatetimePickerBrutal };
