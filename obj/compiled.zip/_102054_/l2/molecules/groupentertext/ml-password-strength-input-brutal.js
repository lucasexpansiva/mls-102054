var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupentertext/ml-password-strength-input-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// PASSWORD STRENGTH INPUT — BRUTALISM (mls-102054) — Strategy D
// =============================================================================
// Shell: herda tudo de PasswordStrengthInputMolecule (mls-102040).
// O render() herdado emite classes ml-*; toda a aparência vive no .less.
import { customElement } from 'lit/decorators.js';
import { PasswordStrengthInputMolecule } from '/_102040_/l2/molecules/groupentertext/ml-password-strength-input.js';
let PasswordStrengthInputBrutal = class PasswordStrengthInputBrutal extends PasswordStrengthInputMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-password-strength-input-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-surface: #ffffff;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-shadow-1: 3px 3px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  display: block;
  font-family: var(--ml-font-family, monospace);
}
groupentertext--ml-password-strength-input-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertext--ml-password-strength-input-brutal .ml-label {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupentertext--ml-password-strength-input-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
}
groupentertext--ml-password-strength-input-brutal p.ml-error-text {
  font-weight: 700;
  text-transform: uppercase;
}
groupentertext--ml-password-strength-input-brutal .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: var(--ml-shadow-1, 3px 3px 0 #000000);
  transition: none;
}
groupentertext--ml-password-strength-input-brutal .ml-input-container:focus-within {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupentertext--ml-password-strength-input-brutal .ml-input-container:has(input[readonly]) {
  background: #f5f5f5;
}
groupentertext--ml-password-strength-input-brutal .ml-input-container-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 3px 3px 0 var(--ml-error, #ef4444);
}
groupentertext--ml-password-strength-input-brutal .ml-disabled .ml-input-container {
  border-color: #999999;
  box-shadow: 3px 3px 0 #999999;
}
groupentertext--ml-password-strength-input-brutal .ml-input {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
}
groupentertext--ml-password-strength-input-brutal .ml-input::placeholder {
  color: var(--ml-on-surface-muted, #999999);
}
groupentertext--ml-password-strength-input-brutal .ml-text-faint {
  color: #999999;
}
groupentertext--ml-password-strength-input-brutal span.ml-text-faint {
  color: #000000;
}
groupentertext--ml-password-strength-input-brutal button.ml-text-faint {
  background: transparent;
  border: none;
  border-left: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: 0;
  color: #000000;
  cursor: pointer;
  transition: none;
}
groupentertext--ml-password-strength-input-brutal button.ml-text-faint:hover:not(:disabled) {
  background: #000000;
  color: #ffffff;
}
groupentertext--ml-password-strength-input-brutal button.ml-text-faint:disabled {
  border-left-color: #999999;
  cursor: not-allowed;
}
groupentertext--ml-password-strength-input-brutal .ml-helper {
  color: #666666;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-track {
  background: #e5e5e5;
  border: 2px solid #000000;
  border-radius: 0;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-weak,
groupentertext--ml-password-strength-input-brutal .ml-strength-fair,
groupentertext--ml-password-strength-input-brutal .ml-strength-strong {
  border-radius: 0;
  transition: none;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-weak {
  background-color: #ef4444;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-fair {
  background-color: #f59e0b;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-strong {
  background-color: #22c55e;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-strong.w-full {
  background-color: #000000;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-weak-text {
  color: #ef4444;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-fair-text {
  color: #f59e0b;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-strong-text {
  color: #22c55e;
}
groupentertext--ml-password-strength-input-brutal .ml-strength-track:has(> .w-full) + .ml-strength-strong-text {
  color: #000000;
}
groupentertext--ml-password-strength-input-brutal span.ml-strength-weak-text,
groupentertext--ml-password-strength-input-brutal span.ml-strength-fair-text,
groupentertext--ml-password-strength-input-brutal span.ml-strength-strong-text {
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupentertext--ml-password-strength-input-brutal div.ml-strength-strong-text {
  font-weight: 700;
}
groupentertext--ml-password-strength-input-brutal .ml-spinner {
  color: #000000;
}
groupentertext--ml-password-strength-input-brutal .animate-spin {
  animation-timing-function: steps(8);
}
groupentertext--ml-password-strength-input-brutal .ml-text-muted {
  color: #000000;
}
groupentertext--ml-password-strength-input-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  letter-spacing: 0.15em;
}
`);
    }
};
PasswordStrengthInputBrutal = __decorate([
    customElement('groupentertext--ml-password-strength-input-brutal')
], PasswordStrengthInputBrutal);
export { PasswordStrengthInputBrutal };
