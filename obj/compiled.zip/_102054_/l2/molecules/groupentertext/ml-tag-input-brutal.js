var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupentertext/ml-tag-input-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TAG INPUT — BRUTALISM (mls-102054)
// =============================================================================
// Skill Group: groupEnterText
// Casca (estratégia D): herda tudo de MlTagInputMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlTagInputMolecule } from '/_102040_/l2/molecules/groupentertext/ml-tag-input.js';
let MlTagInputBrutal = class MlTagInputBrutal extends MlTagInputMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-tag-input-brutal {
  display: block;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-border-style: solid;
  --ml-outline-variant: #000000;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f5f5f5;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-shadow-1: 3px 3px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
}
groupentertext--ml-tag-input-brutal .ml-label {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupentertext--ml-tag-input-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, monospace);
}
groupentertext--ml-tag-input-brutal p.ml-error-text {
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
}
groupentertext--ml-tag-input-brutal .ml-helper {
  color: #666666;
  font-family: var(--ml-font-family, monospace);
}
groupentertext--ml-tag-input-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
}
groupentertext--ml-tag-input-brutal .ml-text-muted {
  color: #666666;
  font-family: var(--ml-font-family, monospace);
}
groupentertext--ml-tag-input-brutal .ml-text-faint {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
}
groupentertext--ml-tag-input-brutal .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  box-shadow: var(--ml-shadow-1, 3px 3px 0 #000000);
  transition: none;
}
groupentertext--ml-tag-input-brutal .ml-input-container:focus-within {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupentertext--ml-tag-input-brutal .ml-input-container:has(input[readonly], textarea[readonly]) {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupentertext--ml-tag-input-brutal .ml-input-container-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 3px 3px 0 #ef4444;
}
groupentertext--ml-tag-input-brutal .ml-input-container.ml-disabled {
  border-color: #999999;
  box-shadow: 3px 3px 0 #999999;
}
groupentertext--ml-tag-input-brutal .ml-input {
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, monospace);
}
groupentertext--ml-tag-input-brutal .ml-input::placeholder {
  color: var(--ml-on-surface-muted, #999999);
}
groupentertext--ml-tag-input-brutal .ml-tag {
  background: #000000;
  color: #ffffff;
  border: 2px solid #000000;
  border-radius: var(--ml-radius-sm, 0);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupentertext--ml-tag-input-brutal .ml-tag-remove {
  color: #ffffff;
  border-radius: 0;
  cursor: pointer;
  transition: none;
}
groupentertext--ml-tag-input-brutal .ml-tag-remove:hover {
  background: var(--ml-error, #ef4444);
  color: #ffffff;
}
groupentertext--ml-tag-input-brutal .ml-tag-remove:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupentertext--ml-tag-input-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertext--ml-tag-input-brutal .ml-loading-overlay {
  background: rgba(255, 255, 255, 0.85);
  border: 3px solid #000000;
  border-radius: 0;
  color: #000000;
}
groupentertext--ml-tag-input-brutal .animate-spin {
  animation-timing-function: steps(8);
}
`);
    }
};
MlTagInputBrutal = __decorate([
    customElement('groupentertext--ml-tag-input-brutal')
], MlTagInputBrutal);
export { MlTagInputBrutal };
