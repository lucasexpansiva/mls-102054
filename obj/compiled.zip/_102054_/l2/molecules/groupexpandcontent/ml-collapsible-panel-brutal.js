var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupexpandcontent/ml-collapsible-panel-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// COLLAPSIBLE PANEL — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlCollapsiblePanelMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlCollapsiblePanelMolecule } from '/_102040_/l2/molecules/groupexpandcontent/ml-collapsible-panel.js';
let MlCollapsiblePanelBrutal = class MlCollapsiblePanelBrutal extends MlCollapsiblePanelMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-collapsible-panel-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #eeeeee;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #666666;
  --ml-shadow-1: 3px 3px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  display: block;
  font-family: var(--ml-font-family);
}
groupexpandcontent--ml-collapsible-panel-brutal div.ml-label {
  font-weight: var(--ml-font-weight-medium);
  color: var(--ml-on-surface);
  text-transform: var(--ml-text-transform);
  letter-spacing: var(--ml-letter-spacing);
}
groupexpandcontent--ml-collapsible-panel-brutal span.ml-label {
  color: var(--ml-on-surface);
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-text-muted {
  color: var(--ml-on-surface-muted);
}
groupexpandcontent--ml-collapsible-panel-brutal span.ml-text-muted:first-child {
  color: var(--ml-on-surface);
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-skeleton {
  background: var(--ml-surface-dim);
  border-radius: var(--ml-radius-sm);
  border: var(--ml-border-width) solid var(--ml-outline-variant);
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-header {
  background: var(--ml-surface);
  border: var(--ml-border-width) solid var(--ml-outline-variant);
  overflow: hidden;
  box-shadow: var(--ml-shadow-1);
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-header:has(> .ml-panel-header-open) {
  border-color: var(--ml-primary);
  box-shadow: 3px 3px 0 var(--ml-primary);
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-header > .ml-panel-header {
  border: none;
  box-shadow: none;
  font-weight: var(--ml-font-weight-medium);
  text-transform: var(--ml-text-transform);
  letter-spacing: var(--ml-letter-spacing);
  transition: none;
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-header > .ml-panel-header:not(.ml-disabled):not(.ml-panel-header-open):hover {
  background: var(--ml-surface-dim);
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-header > .ml-panel-header:focus-visible {
  outline: var(--ml-border-width) solid var(--ml-outline-variant);
  outline-offset: 2px;
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-header > .ml-panel-header.ml-disabled {
  opacity: var(--ml-disabled-opacity);
  border-color: #999999;
  cursor: not-allowed;
  pointer-events: none;
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-header-open {
  background: var(--ml-primary);
  color: var(--ml-on-primary);
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-header-open span.ml-label {
  color: var(--ml-on-primary);
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-header-open span.ml-text-muted:first-child {
  color: var(--ml-on-primary);
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-header-open span.ml-label + .ml-text-muted {
  color: rgba(255, 255, 255, 0.8);
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-chevron {
  color: var(--ml-on-surface);
  transition: none;
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-chevron-open {
  color: var(--ml-on-primary);
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-content {
  border-top: var(--ml-border-width) solid var(--ml-outline-variant);
  background: var(--ml-surface);
  transition: none;
}
groupexpandcontent--ml-collapsible-panel-brutal .ml-panel-content .ml-panel-content {
  border-top: none;
  color: var(--ml-on-surface);
}
`);
    }
};
MlCollapsiblePanelBrutal = __decorate([
    customElement('groupexpandcontent--ml-collapsible-panel-brutal')
], MlCollapsiblePanelBrutal);
export { MlCollapsiblePanelBrutal };
