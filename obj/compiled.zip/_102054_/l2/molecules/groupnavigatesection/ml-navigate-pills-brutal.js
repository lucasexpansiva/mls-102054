var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnavigatesection/ml-navigate-pills-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// NAVIGATE PILLS — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de NavigatePillsMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { NavigatePillsMolecule } from '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills.js';
let NavigatePillsBrutal = class NavigatePillsBrutal extends NavigatePillsMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-navigate-pills-brutal {
  display: block;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-surface: #ffffff;
  --ml-on-surface: #000000;
  --ml-error: #ef4444;
  --ml-shadow-1: 3px 3px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupnavigatesection--ml-navigate-pills-brutal .ml-label {
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupnavigatesection--ml-navigate-pills-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
}
groupnavigatesection--ml-navigate-pills-brutal .ml-text-muted {
  color: #666666;
}
groupnavigatesection--ml-navigate-pills-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
}
groupnavigatesection--ml-navigate-pills-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupnavigatesection--ml-navigate-pills-brutal .ml-nav-pill {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  box-shadow: var(--ml-shadow-1, 3px 3px 0 #000000);
  transition: none;
}
groupnavigatesection--ml-navigate-pills-brutal .ml-nav-pill.cursor-pointer:not(.ml-nav-pill-active):hover {
  background: #eeeeee;
}
groupnavigatesection--ml-navigate-pills-brutal .ml-nav-pill:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupnavigatesection--ml-navigate-pills-brutal .ml-nav-pill.ml-disabled {
  border-color: #999999;
}
groupnavigatesection--ml-navigate-pills-brutal .ml-nav-pill.ml-text-muted {
  color: #666666;
}
groupnavigatesection--ml-navigate-pills-brutal .ml-nav-pill-active {
  background: #000000;
  color: #ffffff;
}
groupnavigatesection--ml-navigate-pills-brutal .ml-nav-pill-panel {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  background: var(--ml-surface, #ffffff);
  box-shadow: var(--ml-shadow-1, 3px 3px 0 #000000);
}
`);
    }
};
NavigatePillsBrutal = __decorate([
    customElement('groupnavigatesection--ml-navigate-pills-brutal')
], NavigatePillsBrutal);
export { NavigatePillsBrutal };
