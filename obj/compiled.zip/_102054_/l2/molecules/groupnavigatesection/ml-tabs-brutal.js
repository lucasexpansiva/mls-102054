var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnavigatesection/ml-tabs-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TABS — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlTabsMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlTabsMolecule } from '/_102040_/l2/molecules/groupnavigatesection/ml-tabs.js';
let MlTabsBrutal = class MlTabsBrutal extends MlTabsMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-tabs-brutal {
  display: block;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-surface: #ffffff;
  --ml-on-surface: #000000;
  --ml-error: #ef4444;
  --ml-shadow-1: 3px 3px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupnavigatesection--ml-tabs-brutal .ml-label {
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupnavigatesection--ml-tabs-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
}
groupnavigatesection--ml-tabs-brutal .ml-text-muted {
  color: #666666;
}
groupnavigatesection--ml-tabs-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupnavigatesection--ml-tabs-brutal .ml-tab-list {
  border-bottom: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
}
groupnavigatesection--ml-tabs-brutal .ml-tab {
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-bottom: none;
  background: #eeeeee;
  color: var(--ml-on-surface, #000000);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  transition: none;
}
groupnavigatesection--ml-tabs-brutal .ml-tab.cursor-pointer:not(.ml-tab-active):hover {
  background: #dddddd;
}
groupnavigatesection--ml-tabs-brutal .ml-tab:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupnavigatesection--ml-tabs-brutal .ml-tab.ml-disabled {
  border-color: #999999;
}
groupnavigatesection--ml-tabs-brutal .ml-tab-active {
  background: #000000;
  color: #ffffff;
}
groupnavigatesection--ml-tabs-brutal .ml-tab-panel {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-top: none;
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  box-shadow: var(--ml-shadow-1, 3px 3px 0 #000000);
}
groupnavigatesection--ml-tabs-brutal .ml-tab-container {
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  background: var(--ml-surface, #ffffff);
  box-shadow: var(--ml-shadow-1, 3px 3px 0 #000000);
}
`);
    }
};
MlTabsBrutal = __decorate([
    customElement('groupnavigatesection--ml-tabs-brutal')
], MlTabsBrutal);
export { MlTabsBrutal };
