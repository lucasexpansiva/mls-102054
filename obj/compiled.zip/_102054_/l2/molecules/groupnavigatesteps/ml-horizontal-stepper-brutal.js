var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// HORIZONTAL STEPPER — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlHorizontalStepperMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlHorizontalStepperMolecule } from '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper.js';
let MlHorizontalStepperBrutal = class MlHorizontalStepperBrutal extends MlHorizontalStepperMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnavigatesteps--ml-horizontal-stepper-brutal {
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-on-surface: #000000;
  --ml-disabled-opacity: 0.4;
  --ml-shadow-1: 3px 3px 0 #000000;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
  display: block;
  font-family: var(--ml-font-family);
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-label {
  color: var(--ml-on-surface);
  text-transform: var(--ml-text-transform);
  letter-spacing: var(--ml-letter-spacing);
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-text {
  color: var(--ml-on-surface);
  text-transform: var(--ml-text-transform);
  letter-spacing: var(--ml-letter-spacing);
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-step-active-text {
  color: var(--ml-primary);
  text-transform: var(--ml-text-transform);
  letter-spacing: var(--ml-letter-spacing);
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-text-muted {
  color: #666666;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-text.ml-text-muted,
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-step-active-text.ml-text-muted {
  color: #999999;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity);
  cursor: not-allowed;
  pointer-events: none;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-step-number {
  border-radius: var(--ml-radius-sm);
  border: var(--ml-border-width) solid var(--ml-outline-variant);
  background: var(--ml-surface);
  color: var(--ml-on-surface);
  box-shadow: var(--ml-shadow-1);
  transition: none;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-step-number:not(.ml-disabled):not(.ml-step-active):hover {
  background: #eeeeee;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-step-number:focus-visible {
  outline: var(--ml-border-width) solid #000000;
  outline-offset: 2px;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-step-active {
  background: var(--ml-primary);
  border-color: var(--ml-outline-variant);
  color: var(--ml-on-primary);
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-step-completed {
  background: var(--ml-on-surface);
  border-color: var(--ml-outline-variant);
  color: var(--ml-on-primary);
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-step-number.ml-disabled {
  border-color: #999999;
  box-shadow: 3px 3px 0 #999999;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-step-connector {
  background: #cccccc;
  height: 3px;
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-step-connector-completed {
  background: var(--ml-on-surface);
}
groupnavigatesteps--ml-horizontal-stepper-brutal .ml-step-loading-dot {
  background: var(--ml-on-surface);
}
`);
    }
};
MlHorizontalStepperBrutal = __decorate([
    customElement('groupnavigatesteps--ml-horizontal-stepper-brutal')
], MlHorizontalStepperBrutal);
export { MlHorizontalStepperBrutal };
