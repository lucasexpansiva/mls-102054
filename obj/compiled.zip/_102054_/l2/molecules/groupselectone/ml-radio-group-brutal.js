var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupselectone/ml-radio-group-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// RADIO GROUP — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlRadioGroupMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlRadioGroupMolecule } from '/_102040_/l2/molecules/groupselectone/ml-radio-group.js';
let MlRadioGroupBrutal = class MlRadioGroupBrutal extends MlRadioGroupMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-radio-group-brutal {
  display: block;
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-error: #ef4444;
  --ml-surface: #ffffff;
  --ml-border-width: 3px;
  --ml-border-style: solid;
  --ml-outline-variant: #000000;
  --ml-radius-md: 0;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
groupselectone--ml-radio-group-brutal .ml-label {
  font-weight: var(--ml-font-weight-medium, 700);
  color: var(--ml-on-surface, #000000);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
}
groupselectone--ml-radio-group-brutal .ml-helper {
  color: #555555;
}
groupselectone--ml-radio-group-brutal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-weight: var(--ml-font-weight-medium, 700);
}
groupselectone--ml-radio-group-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
}
groupselectone--ml-radio-group-brutal .ml-text-muted {
  color: var(--ml-on-surface-muted, #999999);
}
groupselectone--ml-radio-group-brutal span.ml-text-muted:not(.ml-text) {
  color: #555555;
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
}
groupselectone--ml-radio-group-brutal div.ml-text-muted {
  color: #666666;
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
}
groupselectone--ml-radio-group-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-radio-group-brutal .ml-radio-option {
  position: relative;
  border-radius: var(--ml-radius-md, 0);
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  background: var(--ml-surface, #ffffff);
  box-shadow: 2px 2px 0 #000000;
  transition: none;
}
groupselectone--ml-radio-group-brutal .ml-radio-option:hover:not(.ml-disabled):not(.ml-radio-option-selected) {
  background: #f5f5f5;
  transform: translate(-1px, -1px);
  box-shadow: 3px 3px 0 #000000;
}
groupselectone--ml-radio-group-brutal .ml-radio-option-selected {
  background: #000000;
  color: #ffffff;
  box-shadow: 1px 1px 0 #000000;
  transform: translate(1px, 1px);
}
groupselectone--ml-radio-group-brutal .ml-radio-option-focused {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupselectone--ml-radio-group-brutal .ml-radio-option-error {
  border-color: var(--ml-error, #ef4444);
  box-shadow: 2px 2px 0 #ef4444;
}
groupselectone--ml-radio-group-brutal .ml-radio-option.ml-disabled {
  border-color: #999999;
}
groupselectone--ml-radio-group-brutal .ml-radio-dot {
  border: var(--ml-border-width, 3px) var(--ml-border-style, solid) var(--ml-outline-variant, #000000);
  background: var(--ml-surface, #ffffff);
}
groupselectone--ml-radio-group-brutal .ml-radio-dot-selected {
  border-color: #ffffff;
  background: var(--ml-primary, #3b82f6);
}
groupselectone--ml-radio-group-brutal .ml-radio-dot.ml-disabled {
  border-color: #999999;
}
groupselectone--ml-radio-group-brutal .ml-radio-dot-inner {
  background: var(--ml-on-primary, #ffffff);
}
groupselectone--ml-radio-group-brutal .ml-radio-label-selected {
  color: #ffffff;
  font-weight: var(--ml-font-weight-medium, 700);
}
groupselectone--ml-radio-group-brutal .ml-select-group-label {
  color: #555555;
  font-weight: var(--ml-font-weight-medium, 700);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  border-bottom: 2px solid #000000;
}
groupselectone--ml-radio-group-brutal .ml-spinner {
  border-color: #000000;
}
groupselectone--ml-radio-group-brutal .animate-spin {
  animation-timing-function: steps(8);
}
`);
    }
};
MlRadioGroupBrutal = __decorate([
    customElement('groupselectone--ml-radio-group-brutal')
], MlRadioGroupBrutal);
export { MlRadioGroupBrutal };
