var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupshowprogress/ml-circular-progress-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CIRCULAR PROGRESS — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de CircularProgressMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { CircularProgressMolecule } from '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress.js';
let CircularProgressBrutal = class CircularProgressBrutal extends CircularProgressMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupshowprogress--ml-circular-progress-brutal {
  display: inline-block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupshowprogress--ml-circular-progress-brutal .ml-stroke-track {
  stroke: #e5e5e5;
}
groupshowprogress--ml-circular-progress-brutal .ml-stroke-primary {
  stroke: #3b82f6;
}
groupshowprogress--ml-circular-progress-brutal .ml-text {
  color: #000000;
  font-weight: 700;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
`);
    }
};
CircularProgressBrutal = __decorate([
    customElement('groupshowprogress--ml-circular-progress-brutal')
], CircularProgressBrutal);
export { CircularProgressBrutal };
