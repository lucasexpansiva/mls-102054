var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupshowprogress/ml-linear-progress-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// LINEAR PROGRESS — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de LinearProgressMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { LinearProgressMolecule } from '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress.js';
let LinearProgressBrutal = class LinearProgressBrutal extends LinearProgressMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupshowprogress--ml-linear-progress-brutal {
  display: block;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupshowprogress--ml-linear-progress-brutal .ml-text-muted {
  color: #000000;
  font-weight: 700;
  font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
}
groupshowprogress--ml-linear-progress-brutal .ml-surface-dim-bg {
  background: #e5e5e5;
  border: 3px solid #000000;
  border-radius: 0;
  box-shadow: 3px 3px 0 #000000;
}
groupshowprogress--ml-linear-progress-brutal .ml-primary-bg,
groupshowprogress--ml-linear-progress-brutal .ml-success-bg,
groupshowprogress--ml-linear-progress-brutal .ml-warning-bg,
groupshowprogress--ml-linear-progress-brutal .ml-error-bg {
  border-radius: 0;
}
groupshowprogress--ml-linear-progress-brutal .ml-primary-bg {
  background: #3b82f6;
}
groupshowprogress--ml-linear-progress-brutal .ml-success-bg {
  background: #10b981;
}
groupshowprogress--ml-linear-progress-brutal .ml-warning-bg {
  background: #f59e0b;
}
groupshowprogress--ml-linear-progress-brutal .ml-error-bg {
  background: #ef4444;
}
groupshowprogress--ml-linear-progress-brutal .mlp-indeterminate {
  animation-timing-function: steps(20);
}
`);
    }
};
LinearProgressBrutal = __decorate([
    customElement('groupshowprogress--ml-linear-progress-brutal')
], LinearProgressBrutal);
export { LinearProgressBrutal };
