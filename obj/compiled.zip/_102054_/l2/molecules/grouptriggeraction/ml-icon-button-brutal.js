var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/grouptriggeraction/ml-icon-button-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ICON BUTTON — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de IconButtonMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { IconButtonMolecule } from '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button.js';
let IconButtonBrutal = class IconButtonBrutal extends IconButtonMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-icon-button-brutal {
  display: inline-block;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f0f0f0;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #999999;
  --ml-shadow-1: 3px 3px 0 #000000;
  --ml-shadow-2: 1px 1px 0 #000000;
  --ml-disabled-opacity: 0.4;
}
grouptriggeraction--ml-icon-button-brutal .ml-button {
  appearance: none;
  position: relative;
  border-radius: var(--ml-radius-sm, 0);
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  box-shadow: var(--ml-shadow-1, 3px 3px 0 #000000);
  transition: none;
}
grouptriggeraction--ml-icon-button-brutal .ml-button:not(.ml-disabled):hover {
  box-shadow: var(--ml-shadow-2, 1px 1px 0 #000000);
  transform: translate(2px, 2px);
}
grouptriggeraction--ml-icon-button-brutal .ml-button:not(.ml-disabled):active {
  box-shadow: 0 0 0 #000000;
  transform: translate(3px, 3px);
}
grouptriggeraction--ml-icon-button-brutal .ml-button:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
grouptriggeraction--ml-icon-button-brutal .ml-button-secondary {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
}
grouptriggeraction--ml-icon-button-brutal .ml-button-secondary:not(.ml-disabled):hover {
  background: var(--ml-surface-dim, #f0f0f0);
}
grouptriggeraction--ml-icon-button-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
  border-color: var(--ml-on-surface-muted, #999999);
  box-shadow: 2px 2px 0 var(--ml-on-surface-muted, #999999);
}
grouptriggeraction--ml-icon-button-brutal .ml-disabled.cursor-wait {
  cursor: wait;
}
grouptriggeraction--ml-icon-button-brutal .ml-button > span[aria-hidden='true'] {
  color: var(--ml-on-surface, #000000);
  padding: 22%;
}
grouptriggeraction--ml-icon-button-brutal .ml-disabled > span[aria-hidden='true'] {
  color: var(--ml-on-surface-muted, #999999);
}
grouptriggeraction--ml-icon-button-brutal .animate-spin {
  animation-timing-function: steps(8);
}
`);
    }
};
IconButtonBrutal = __decorate([
    customElement('grouptriggeraction--ml-icon-button-brutal')
], IconButtonBrutal);
export { IconButtonBrutal };
