var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/grouptriggeraction/ml-split-button-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SPLIT BUTTON — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlSplitButtonMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlSplitButtonMolecule } from '/_102040_/l2/molecules/grouptriggeraction/ml-split-button.js';
let MlSplitButtonBrutal = class MlSplitButtonBrutal extends MlSplitButtonMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-split-button-brutal {
  display: inline-block;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 700;
  --ml-radius-sm: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-on-primary: #ffffff;
  --ml-surface: #ffffff;
  --ml-surface-dim: #f0f0f0;
  --ml-on-surface: #000000;
  --ml-shadow-1: 4px 4px 0 #000000;
  --ml-shadow-2: 2px 2px 0 #000000;
  --ml-disabled-opacity: 0.4;
  --ml-text-transform: uppercase;
  --ml-letter-spacing: 0.05em;
}
grouptriggeraction--ml-split-button-brutal .ml-split-trigger,
grouptriggeraction--ml-split-button-brutal .ml-split-dropdown {
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: var(--ml-font-weight-medium, 700);
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: var(--ml-letter-spacing, 0.05em);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
  transition: none;
}
grouptriggeraction--ml-split-button-brutal .ml-split-trigger:not(.ml-disabled):hover,
grouptriggeraction--ml-split-button-brutal .ml-split-dropdown:not(.ml-disabled):hover {
  background: #2563eb;
  box-shadow: var(--ml-shadow-2, 2px 2px 0 #000000);
  transform: translate(2px, 2px);
}
grouptriggeraction--ml-split-button-brutal .ml-split-trigger:not(.ml-disabled):active,
grouptriggeraction--ml-split-button-brutal .ml-split-dropdown:not(.ml-disabled):active {
  box-shadow: 0 0 0 #000000;
  transform: translate(4px, 4px);
}
grouptriggeraction--ml-split-button-brutal .ml-split-trigger:focus-visible,
grouptriggeraction--ml-split-button-brutal .ml-split-dropdown:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
grouptriggeraction--ml-split-button-brutal .ml-split-dropdown {
  border-left: none;
}
grouptriggeraction--ml-split-button-brutal .ml-split-trigger.ml-disabled,
grouptriggeraction--ml-split-button-brutal .ml-split-dropdown.ml-disabled {
  border-color: #999999;
  box-shadow: 2px 2px 0 #999999;
}
grouptriggeraction--ml-split-button-brutal .ml-split-menu {
  border: var(--ml-border-width, 3px) solid var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-sm, 0);
  background: var(--ml-surface, #ffffff);
  box-shadow: var(--ml-shadow-1, 4px 4px 0 #000000);
}
grouptriggeraction--ml-split-button-brutal .ml-split-item {
  border-radius: var(--ml-radius-sm, 0);
  border: none;
  background: transparent;
  color: var(--ml-on-surface, #000000);
  font-family: var(--ml-font-family, 'JetBrains Mono', 'SF Mono', 'Courier New', monospace);
  font-weight: 600;
  text-transform: var(--ml-text-transform, uppercase);
  letter-spacing: 0.03em;
  transition: none;
}
grouptriggeraction--ml-split-button-brutal .ml-split-item:not(.ml-disabled):hover {
  background: var(--ml-surface-dim, #f0f0f0);
}
grouptriggeraction--ml-split-button-brutal .ml-split-item:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
grouptriggeraction--ml-split-button-brutal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
MlSplitButtonBrutal = __decorate([
    customElement('grouptriggeraction--ml-split-button-brutal')
], MlSplitButtonBrutal);
export { MlSplitButtonBrutal };
