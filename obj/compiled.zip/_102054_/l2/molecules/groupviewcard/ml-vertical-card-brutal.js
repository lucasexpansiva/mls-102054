var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupviewcard/ml-vertical-card-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// VERTICAL CARD — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlVerticalCardMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlVerticalCardMolecule } from '/_102040_/l2/molecules/groupviewcard/ml-vertical-card.js';
let MlVerticalCardBrutal = class MlVerticalCardBrutal extends MlVerticalCardMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupviewcard--ml-vertical-card-brutal {
  display: block;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-font-weight-medium: 900;
  --ml-radius-md: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-primary: #3b82f6;
  --ml-surface: #ffffff;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #555555;
  --ml-disabled-opacity: 0.4;
  font-family: var(--ml-font-family);
}
groupviewcard--ml-vertical-card-brutal .ml-card {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #000000);
  border-width: var(--ml-border-width, 3px);
  border-style: solid;
  border-color: var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-md, 0);
  box-shadow: 4px 4px 0 #000000;
  transition: none;
}
groupviewcard--ml-vertical-card-brutal .ml-card-header {
  background: #dbeafe;
  border-color: var(--ml-primary, #3b82f6);
  box-shadow: 4px 4px 0 #3b82f6;
}
groupviewcard--ml-vertical-card-brutal .ml-card-hover:hover {
  box-shadow: 2px 2px 0 #000000;
  transform: translate(2px, 2px);
}
groupviewcard--ml-vertical-card-brutal .ml-card-hover:focus-visible {
  outline: 3px solid #000000;
  outline-offset: 2px;
}
groupviewcard--ml-vertical-card-brutal .ml-card.ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.4);
  cursor: not-allowed;
  pointer-events: none;
  border-color: #999999;
  box-shadow: 2px 2px 0 #999999;
}
groupviewcard--ml-vertical-card-brutal .ml-card-divider {
  border-top-width: var(--ml-border-width, 3px);
  border-color: var(--ml-outline-variant, #000000);
}
groupviewcard--ml-vertical-card-brutal .ml-label {
  font-family: var(--ml-font-family);
  font-weight: var(--ml-font-weight-medium, 900);
  color: var(--ml-on-surface, #000000);
  text-transform: uppercase;
  letter-spacing: 0.03em;
}
groupviewcard--ml-vertical-card-brutal .ml-text {
  color: #333333;
}
groupviewcard--ml-vertical-card-brutal .text-sm.ml-text-muted {
  color: var(--ml-on-surface-muted, #555555);
}
groupviewcard--ml-vertical-card-brutal .text-xs.ml-text-muted {
  color: #777777;
}
groupviewcard--ml-vertical-card-brutal .ml-skeleton {
  border-radius: var(--ml-radius-md, 0);
  background: #e5e5e5;
  border: 2px solid #cccccc;
  animation: brutal-card-pulse 1.4s steps(4) infinite;
}
@keyframes brutal-card-pulse {
  0%,
  100% {
    opacity: 0.6;
  }
  50% {
    opacity: 0.25;
  }
}
`);
    }
};
MlVerticalCardBrutal = __decorate([
    customElement('groupviewcard--ml-vertical-card-brutal')
], MlVerticalCardBrutal);
export { MlVerticalCardBrutal };
