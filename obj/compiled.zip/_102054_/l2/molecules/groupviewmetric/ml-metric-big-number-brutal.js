var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupviewmetric/ml-metric-big-number-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// METRIC BIG NUMBER — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MlMetricBigNumberMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlMetricBigNumberMolecule } from '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number.js';
let MlMetricBigNumberBrutal = class MlMetricBigNumberBrutal extends MlMetricBigNumberMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupviewmetric--ml-metric-big-number-brutal {
  display: block;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-radius-md: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-surface: #ffffff;
  --ml-on-surface: #000000;
  font-family: var(--ml-font-family);
}
groupviewmetric--ml-metric-big-number-brutal .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
  box-shadow: 4px 4px 0 #000000;
}
groupviewmetric--ml-metric-big-number-brutal .ml-border {
  border-width: var(--ml-border-width, 3px);
  border-style: solid;
  border-color: var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-md, 0);
}
groupviewmetric--ml-metric-big-number-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
}
groupviewmetric--ml-metric-big-number-brutal .flex.ml-text-muted {
  color: #000000;
}
groupviewmetric--ml-metric-big-number-brutal .text-sm.font-medium.ml-text-muted:not(.inline-flex) {
  color: #555555;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupviewmetric--ml-metric-big-number-brutal .text-xs.ml-text-muted {
  color: #777777;
}
groupviewmetric--ml-metric-big-number-brutal .inline-flex.ml-text-muted {
  color: #777777;
}
groupviewmetric--ml-metric-big-number-brutal .ml-success-text {
  color: #10b981;
}
groupviewmetric--ml-metric-big-number-brutal .ml-error-text {
  color: #ef4444;
}
groupviewmetric--ml-metric-big-number-brutal .ml-surface-dim-bg {
  background: #e5e5e5;
  border: 2px solid #cccccc;
  border-radius: 0;
  animation: brutal-bn-pulse 1.4s steps(4) infinite;
}
@keyframes brutal-bn-pulse {
  0%,
  100% {
    opacity: 0.6;
  }
  50% {
    opacity: 0.25;
  }
}
`);
    }
};
MlMetricBigNumberBrutal = __decorate([
    customElement('groupviewmetric--ml-metric-big-number-brutal')
], MlMetricBigNumberBrutal);
export { MlMetricBigNumberBrutal };
