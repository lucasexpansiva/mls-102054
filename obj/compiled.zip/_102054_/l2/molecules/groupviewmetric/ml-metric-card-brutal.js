var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102054_/l2/molecules/groupviewmetric/ml-metric-card-brutal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// METRIC CARD — BRUTALISM (mls-102054)
// =============================================================================
// Casca (estratégia D): herda tudo de MetricCardMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência brutal vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MetricCardMolecule } from '/_102040_/l2/molecules/groupviewmetric/ml-metric-card.js';
let MetricCardBrutal = class MetricCardBrutal extends MetricCardMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupviewmetric--ml-metric-card-brutal {
  display: block;
  --ml-font-family: 'JetBrains Mono', 'SF Mono', 'Courier New', monospace;
  --ml-radius-md: 0;
  --ml-border-width: 3px;
  --ml-outline-variant: #000000;
  --ml-surface: #ffffff;
  --ml-on-surface: #000000;
  --ml-on-surface-muted: #555555;
  font-family: var(--ml-font-family);
}
groupviewmetric--ml-metric-card-brutal .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
  box-shadow: 4px 4px 0 #000000;
  transition: none;
}
groupviewmetric--ml-metric-card-brutal .ml-border {
  border-width: var(--ml-border-width, 3px);
  border-style: solid;
  border-color: var(--ml-outline-variant, #000000);
  border-radius: var(--ml-radius-md, 0);
}
groupviewmetric--ml-metric-card-brutal .ml-text {
  color: var(--ml-on-surface, #000000);
}
groupviewmetric--ml-metric-card-brutal .text-sm.ml-text-muted {
  color: #555555;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
groupviewmetric--ml-metric-card-brutal .text-xs.ml-text-muted:not(.inline-flex) {
  color: #777777;
}
groupviewmetric--ml-metric-card-brutal .justify-center.ml-surface-dim-bg {
  background: #f5f5f5;
  border: 3px solid #000000;
  border-radius: 0;
}
groupviewmetric--ml-metric-card-brutal .rounded-md.ml-surface-dim-bg:not(.ml-border) {
  background: #e5e5e5;
  border: 2px solid #cccccc;
  border-radius: 0;
  animation: brutal-mc-pulse 1.4s steps(4) infinite;
}
@keyframes brutal-mc-pulse {
  0%,
  100% {
    opacity: 0.6;
  }
  50% {
    opacity: 0.25;
  }
}
groupviewmetric--ml-metric-card-brutal .rounded-md.border {
  border-radius: 0;
  border-width: 2px;
  border-color: #000000;
}
groupviewmetric--ml-metric-card-brutal .ml-success-text {
  color: #ffffff;
}
groupviewmetric--ml-metric-card-brutal .ml-success-dim-bg {
  background: #10b981;
}
groupviewmetric--ml-metric-card-brutal .ml-success-border {
  border-color: #000000;
}
groupviewmetric--ml-metric-card-brutal .ml-error-text {
  color: #ffffff;
}
groupviewmetric--ml-metric-card-brutal .ml-error-dim-bg {
  background: #ef4444;
}
groupviewmetric--ml-metric-card-brutal .ml-border-error {
  border-color: #000000;
}
groupviewmetric--ml-metric-card-brutal .ml-text-muted.ml-surface-dim-bg.ml-border {
  color: #000000;
  background: #e5e5e5;
  border-width: 2px;
  border-color: #000000;
}
`);
    }
};
MetricCardBrutal = __decorate([
    customElement('groupviewmetric--ml-metric-card-brutal')
], MetricCardBrutal);
export { MetricCardBrutal };
